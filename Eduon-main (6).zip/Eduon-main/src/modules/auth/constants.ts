export enum GENDER {
   "MALE" = "male",
   "FEMALE" = "female"
}
export enum JOB {
   "BUSINESSMAN" = "businessman",
   "DEVELOPER" = "developer",
   "TEACHER" = "teacher",
   "STUDENT" = "student",
   "OTHER" = "other"
}