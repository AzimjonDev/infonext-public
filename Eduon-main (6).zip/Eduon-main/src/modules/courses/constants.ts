export enum LANGUAGE {
   "EN" = "en",
   "RU" = "ru",
   "UZ" = "uz"
}
export enum TYPE {
   "PAID" = "paid",
   "FREE" = "free"
}
export enum DEGREE {
   "PRIMARY" = "primary",
   "MEDIUM" = "medium",
   "HIGH" = "high"
}
