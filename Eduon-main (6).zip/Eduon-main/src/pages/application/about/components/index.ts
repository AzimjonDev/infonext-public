export { default as Category } from "./category";
export { default as Form } from "./form";
export { default as Header } from "./header";
export { default as Main } from "./main";
export { default as Partner } from "./partner";
