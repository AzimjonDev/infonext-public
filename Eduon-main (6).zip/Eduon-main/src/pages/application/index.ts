export { About } from "./about";
export { Courses } from "./courses";
export { Home } from "./home";
export { NewCourses } from "./new-course";
export { Question } from "./question";
export { Rules } from "./rules";
export { Speakers } from "./speaker";
export { TopCourses } from "./top-course";
