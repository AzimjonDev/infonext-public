export { Main } from "./main";
export { Title } from "./title";
// export { Home } from "./home";
// export { NewCourses } from "./new-course";
// export { Question } from "./question";
// export { Shartlar } from "./shartlar";
// export { Speakers } from "./speaker";
// export { TopCourses } from "./top-course";
