// eslint-disable-next-line import/extensions
export * as Teacher from "./teacher";
export * as User from "./user";
