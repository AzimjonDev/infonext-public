export * as Teacher from "./components";
