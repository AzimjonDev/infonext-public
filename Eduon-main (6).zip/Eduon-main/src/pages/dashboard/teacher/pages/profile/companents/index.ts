export { default as CardPage } from "./card";
export { default as Img } from "./img";
export { default as Main } from "./main";
export { default as TeacherResetPassword } from "./teacherResetPassword";
