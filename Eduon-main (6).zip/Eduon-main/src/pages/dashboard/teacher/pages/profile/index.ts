export { default as ProfileTe } from "./profile";
