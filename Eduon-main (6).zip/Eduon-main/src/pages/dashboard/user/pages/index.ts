export { default as MyAccount } from "./my-account/my-account";
export { default as MyCourses } from "./my-courses/components/course";
