export { default as Img } from "./img";
export { default as Main } from "./main";
export { default as Demo } from "./modal"